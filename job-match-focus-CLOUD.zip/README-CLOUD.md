# Job Match Focus — pack pour Claude Code Cloud (claude.ai/code)

## Ce fichier ZIP est la seule chose à ajouter à GitHub

1. Sur GitHub, crée une branche `design/job-match-focus-inputs` depuis la branche stable de ton projet.
2. Sur cette branche, **Add file > Upload files** et ajoute `job-match-focus-CLOUD.zip` à la racine du repo (sans l’extraire sur ton ordinateur). Commit sur cette branche.
3. Dans https://claude.ai/code, choisis ton repo et la branche `design/job-match-focus-inputs`. Choisis **Accept edits**.
4. Colle le message d’amorçage fourni dans la réponse ChatGPT. Claude doit extraire ce ZIP dans sa VM, suivre `docs/design/PROMPT_CLAUDE_AUTONOME.md` et ouvrir une PR (ou pousser une branche) sans toucher à `main`.

## Après extraction

- `docs/design/PROMPT_CLAUDE_AUTONOME.md` : mission complète d’implémentation autonome.
- `docs/design/JOB_MATCH_FOCUS.md` : contrat de design imposé.
- `docs/design/references/job-match-focus/` : 5 maquettes PNG et `reference.html` (référence statique seulement).

Le ZIP uploadé est un fichier d’entrée temporaire : Claude peut le retirer **de sa branche de travail** après extraction, mais ne doit pas le supprimer de la branche d’entrée pour éviter de casser la référence initiale. Il ne doit jamais déployer, fusionner ou écrire en production.
